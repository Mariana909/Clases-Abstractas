/*
 * Duque Karla-Oviedo Daniel
 */

package ejercicio1;

public class Cuenta {
	protected int numCuenta;
	protected int anioApertura;
	protected String nombreT;
	protected int idT;
	protected String correoT;
	protected long saldo;
	public Cuenta(int numCuenta, int anioApertura, String nombreT, int idT, String correoT) {
		super();
		this.numCuenta = numCuenta;
		this.anioApertura = anioApertura;
		this.nombreT = nombreT;
		this.idT = idT;
		this.correoT = correoT;
	}
	
}
