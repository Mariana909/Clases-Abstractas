/*
 * Duque Karla-Oviedo Daniel
 */

package ejercicio1;

public interface IDepositable {
	public void deposito(long valor);
}
