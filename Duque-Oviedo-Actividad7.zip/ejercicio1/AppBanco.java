/*
 * Duque Karla-Oviedo Daniel
 */

package ejercicio1;

import java.util.ArrayList;

public class AppBanco {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Cuenta>listaCuenta= new ArrayList<Cuenta>();
		Ahorro ahorro = new Ahorro(12244,2010, "Maria Perez", 154585, "maria@hotmail.com", 13466L);
		listaCuenta.add(ahorro);
		System.out.println("Cuenta Ahorros");
		ahorro.deposito(100000L);
		ahorro.retiro(50000L);
		Corriente corriente = new Corriente(4356, 2002, "Carlos Cubios",5245867, "carlos@hotmail.com",null , 1357687);
		System.out.println("Cuenta Corriente: ");
		listaCuenta.add(corriente);
		corriente.deposito(2000000);
		corriente.retiro(4000000L);
		Nomina nomina = new Nomina(21544, 2013, "Wendy Williams", 4687, "wendy@gmail.com", "Candy", null);
		listaCuenta.add(nomina);
		System.out.println("Cuenta Nomina: ");
		nomina.retiro(245551);
		Vivienda vivienda = new Vivienda(64962, 2020, "Ramiro López", 5648, "ramiro@gmail.com", 2500000000L, "Interes social");
		listaCuenta.add(vivienda);
		System.out.println("Cuenta Vivienda: ");
		vivienda.deposito(2000000L);
	}

}