/*
 * Duque Karla-Oviedo Daniel
 */

package ejercicio1;

public interface IRetirable {
	public void retiro(long valor);
}
