/*
 * Duque Karla-Oviedo Daniel
 */

package ejercicio1;

import java.time.LocalDate;

public class Nomina extends Cuenta implements IRetirable {
	private String empresa;
	private LocalDate fechaURetiro;
	public Nomina(int numCuenta, int anioApertura, String nombreT, int idT, String correoT, String empresa,
			LocalDate fechaURetiro) {
		super(numCuenta, anioApertura, nombreT, idT, correoT);
		this.empresa = empresa;
		this.fechaURetiro = fechaURetiro;
	}
	public void retiro(long valor) {
		// TODO Auto-generated method stub
		if(valor>saldo)
			{
				System.out.println("No es posible realizar la operación");
			}else {
				this.saldo-=valor;
				this.fechaURetiro=LocalDate.now();
				System.out.println("Saldo: "+saldo);
			}
	}
}
