/*
 * Duque Karla-Oviedo Daniel
 */

package ejercicio1;

public class Vivienda extends Cuenta implements IDepositable {
	public Vivienda(int numCuenta, int anioApertura, String nombreT, int idT, String correoT, long precioV,
			String tipo) {
		super(numCuenta, anioApertura, nombreT, idT, correoT);
		this.precioV = precioV;
		this.tipo = tipo;
	}
	private long precioV;
	private String tipo;
	@Override
	public void deposito(long valor) {
		// TODO Auto-generated method stub
		if(valor>0) {
			this.saldo+=valor;
			System.out.println("Saldo: "+saldo);
		}else {
			System.out.println("No es posible depositar valores negativos");
		}
	}
	
}
